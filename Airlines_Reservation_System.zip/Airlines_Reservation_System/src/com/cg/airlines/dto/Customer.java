package com.cg.airlines.dto;

public class Customer {
	private long bookingId;
	private String custEmail;
	private int noOfPassengers;
	private String classType;
	private String srcCity;
	private String destCity;
	
	public long getBookingId() {
		return bookingId;
	}

	public void setBookingId(long bookingId) {
		this.bookingId = bookingId;
	}

	public String getCustEmail() {
		return custEmail;
	}

	public void setCustEmail(String custEmail) {
		this.custEmail = custEmail;
	}

	public int getNoOfPassengers() {
		return noOfPassengers;
	}

	public void setNoOfPassengers(int noOfPassengers) {
		this.noOfPassengers = noOfPassengers;
	}

	public String getClassType() {
		return classType;
	}

	public void setClassType(String classType) {
		this.classType = classType;
	}

	public String getSrcCity() {
		return srcCity;
	}

	public void setSrcCity(String srcCity) {
		this.srcCity = srcCity;
	}

	public String getDestCity() {
		return destCity;
	}

	public void setDestCity(String destCity) {
		this.destCity = destCity;
	}
	

	@Override
	public String toString() {
		return "Customer [bookingId=" + bookingId + ", custEmail=" + custEmail
				+ ", noOfPassengers=" + noOfPassengers + ", classType="
				+ classType + ", srcCity=" + srcCity + ", destCity=" + destCity
				+ "]";
	}

	public Customer(long bookingId, String custEmail, int noOfPassengers,
			String classType, String srcCity,
			String destCity) {
		super();
		this.bookingId = bookingId;
		this.custEmail = custEmail;
		this.noOfPassengers = noOfPassengers;
		this.classType = classType;		
		this.srcCity = srcCity;
		this.destCity = destCity;
	}

	public Customer()
	{
		
	}
}
