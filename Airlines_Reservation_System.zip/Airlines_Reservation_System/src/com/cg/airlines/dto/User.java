package com.cg.airlines.dto;

public class User {
	private int userId;
	private String userName;
	private String pasword;
	private String role;
	private long mobileNo;
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPasword() {
		return pasword;
	}
	public void setPasword(String pasword) {
		this.pasword = pasword;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName
				+ ", pasword=" + pasword + ", role=" + role + ", mobileNo="
				+ mobileNo + "]";
	}
	public User(int userId, String userName, String pasword, String role,
			long mobileNo) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.pasword = pasword;
		this.role = role;
		this.mobileNo = mobileNo;
	}
	
}
