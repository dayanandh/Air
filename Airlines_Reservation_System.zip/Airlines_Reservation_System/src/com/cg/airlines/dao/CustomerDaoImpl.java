package com.cg.airlines.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.cg.airlines.dto.Customer;
import com.cg.airlines.dto.User;
import com.cg.airlines.exception.CustomerException;
import com.cg.airlines.logger.MyLogger;
import com.cg.airlines.util.DBUtil;

public class CustomerDaoImpl implements ICustomer{
	Connection con;
	Logger logger;
	
	public CustomerDaoImpl()
	{
		con = DBUtil.getConnect();
		logger=MyLogger.getLogger();
	}
	public int getUserId()throws CustomerException
	{
		logger.info("In getUserId");
		int id = 0;
		String qry = "SELECT uId_seq.CURRVAL FROM DUAL";
			try{
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			if(rs.next())
			{
				id = rs.getInt(1);
				logger.info("Got User With Id"+id);
			}
			}
			catch(SQLException e)
			{
				logger.error("Error"+e.getMessage());
				throw new CustomerException(e.getMessage());
			}
			logger.info("Completed getUserId");
			return id;
		
	}
	public int getBookingId()throws CustomerException
	{
		logger.info("In get BookingId");
		int id = 0;
		
			try{
			String qry = "SELECT bId_seq.CURRVAL FROM DUAL";
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			if(rs.next())
			{
				id = rs.getInt(1);
				logger.info("Got Customer Details with BookingId"+id);
			}
			}
			catch(SQLException e)
			{
				logger.error("error"+e.getMessage());
				throw new CustomerException(e.getMessage());
			}
			logger.info("Completed get Employeeid");
			return id;
		
	}
	@Override
	public int registerCustomer(Customer cust) throws CustomerException {
		// TODO Auto-generated method stub
		logger.info("In RegisterCustomer" );
		logger.info("Input is"+cust);
		
		int id = 0;
		String qry = "INSERT INTO BookingInformation VALUES(bId_seq.NEXTVAL,?,?,?,?,?)";
		String custEmail = cust.getCustEmail();
		int noOfPassengers = cust.getNoOfPassengers();
		String classType = cust.getClassType();
		String srcCity = cust.getSrcCity();
		String destCity = cust.getDestCity();
		try
		{
			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setString(1, custEmail);
			pstmt.setInt(2,noOfPassengers);
			pstmt.setString(3, classType);
			pstmt.setString(4, srcCity);
			pstmt.setString(5, destCity);
			
			int row = pstmt.executeUpdate();
			if(row > 0)
			{
				id = getBookingId();
				logger.info("Inserted successfully and id is="+id);
			}
			else
				throw new CustomerException("unable to insert"+cust);
			
		}
		catch(SQLException e)
		{
			logger.info("Error in insert="+e.getMessage());
			throw new CustomerException(e.getMessage());
		}
		return id;
	}
	@Override
	public Customer removeCustomer(int custId) throws CustomerException {
		// TODO Auto-generated method stub
		Customer cust = null;
		String qry = "DELETE FROM BookingInformation WHERE Booking_Id=?";
		try
		{
			PreparedStatement pstmt = 
					con.prepareStatement(qry);
			pstmt.setInt(1, custId);
			cust = getCustomerById(custId);
			int row = pstmt.executeUpdate();
			if(cust==null)
			{
				throw new CustomerException("Customer with Bookingid "+custId+"not found");
			}
			else if(row > 0)
			{
				System.out.println("Deleted Customer with Bookingid "+custId);
				
			}
			
		}
		catch(SQLException e)
		{
			throw new CustomerException(e.getMessage());
		}
		return cust;
	}
	@Override
	public Customer getCustomerById(int custId) throws CustomerException {
		// TODO Auto-generated method stub
		Customer cust = null;
		String qry = "SELECT * FROM BookingInformation WHERE Booking_Id=?";
		try
		{
			PreparedStatement pstmt = 
					con.prepareStatement(qry);
			pstmt.setInt(1, custId);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next())
			{
				int id = rs.getInt(1);
				String custEmail = rs.getString(2);
				int noOfPassengers = rs.getInt(3);
				String classType = rs.getString(4);
				String srcCity = rs.getString(5);
				String destCity = rs.getString(6);
				
				cust = new Customer(id,custEmail,noOfPassengers,classType,srcCity,destCity);
			}
			else
				throw new CustomerException("Customer with bookingid "+custId+"not found");
		}
		catch(SQLException e)
		{
			throw new CustomerException(e.getMessage());
		}
		return cust;
	}
	@Override
	public ArrayList<Customer> getAllCustomer() throws CustomerException {
		
		ArrayList<Customer>list = new ArrayList<Customer>();
		String qry = "SELECT * FROM BookingInformation";
		try
		{
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			while(rs.next())
			{
				int id = rs.getInt(1);
				String custEmail = rs.getString(2);
				int noOfPassengers = rs.getInt(3);
				String classType = rs.getString(4);
				String srcCity = rs.getString(5);
				String destCity = rs.getString(6);
				Customer cust = new Customer(id,custEmail,noOfPassengers,classType,srcCity,destCity);
				list.add(cust);
			}
		}
		catch(SQLException e)
		{
			throw new CustomerException(e.getMessage());
		}
		return list;
	}
	@Override
	public ArrayList<User> getAllUser() throws CustomerException {
		ArrayList<User>lst = new ArrayList<User>();
		String qry = "SELECT * FROM User";
		try
		{
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			while(rs.next())
			{
				int id = rs.getInt(1);
				String username=rs.getString(2);
				String password=rs.getString(3);
				String role=rs.getString(4);
				long mobile= rs.getLong(5);
				
				
				User usr = new User(id,username,password,role,mobile);
				lst.add(usr);
			}
		}
		catch(SQLException e)
		{
			throw new CustomerException(e.getMessage());
		}
		return lst;
	}
		
}
	